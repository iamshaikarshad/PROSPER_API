from flask import Flask, render_template, jsonify, request, redirect
import sqlalchemy as sa
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL
import pyodbc 
import urllib.parse 
import datetime


app = Flask(__name__)

my_uid = "a.shaik@spenergynetworks.co.uk"
my_pwd = "Fx96dd96$aa"
my_host = "syspwnetworksdataint.sql.azuresynapse.net"
my_db = "syspwnetworksdedicatedpool"
my_odbc_driver = "ODBC Driver 17 for SQL Server"

conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};Server=tcp:syspwnetworksdataint.sql.azuresynapse.net,1433;Database=syspwnetworksdedicatedpool;Uid=a.shaik@spenergynetworks.co.uk;Pwd=<password>;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;Authentication=ActiveDirectoryPassword')

cursor = conn.cursor()

def convert_string_to_datetime(date,time):
    """Converts a string to a datetime object.

    Args:
        combined_date_time: A string containing the date and time in the format `YYYY-MM-DD HH:mm:ss`.

    Returns:
        A datetime object representing the date and time.
    """
    # Parse the date and time parts using the datetime module.
    date_obj = datetime.datetime.strptime(date, '%Y-%m-%d')
    time_obj = datetime.datetime.strptime(time, '%H:%M:%S')
    datetime_obj = datetime.datetime.combine(date_obj, time_obj)

    return datetime_obj

@app.route('/')
def Create_HV():

    cursor.execute("select * from PROSPER.Schemes")
    Scheme = cursor.fetchall()
    cursor.execute("select * from PROSPER.Regions")
    Region = cursor.fetchall()

    print(Scheme)
    if request.method == 'POST':
        
        
        # Create a new record
        Scheme = request.form['Scheme']
        Region = request.form['Region']
        District = request.form['District']
        DOI = request.form['doi']
        TOI = request.form['toi']
        combined_doi = convert_string_to_datetime(DOI, TOI)
        DRR = request.form['drr']
        DRRT = request.form['drrt']
        combined_drr = convert_string_to_datetime(DRR, DRRT)
        Closed_flag = request.form['name']
        RE = request.form['responsible_engineer']
        Eng_Desg = request.form['engineer_Designation']
        Error_status = request.form['Status']
        split_incident = request.form['SplitIncident']
        Status = request.form['name']
        update_time = request.form['name']
        main_circuit = request.form['Circuit']
        Desc1 = request.form['Desc1']
        NPI = request.form['NPI']
        Desc2 = request.form['Desc2']
        API = request.form['API']
        Desc3 = request.form['Desc3']
        Distance = request.form['Distance']
        cursor.execute('INSERT INTO PROSPER.Incidents_Stage1 (SCHEME_CODE,REGION_CODE,OPZONES,I_INC_DATE_TIME,I_REPORT_DATE_TIME, I_CLOSED_FLAG, KH_ENG_NAME,KH_ENG_DESIG,SPLIT_INCIDENT,hl_job_ref_no,I_STATUS,I_LAST_UPDATED,REPORTING SCHEME,I_MAIN_CIRCUIT,I_MC_DESC,H_NEAR_ISOL_POINT,H_NIP_DESC,H_AUTO_ISOL_POINT,H_AIP_DESC) VALUES (?)', 
                       (Scheme,Region,District,combined_doi,combined_drr,'C',RE,Eng_Desg,Error_status,split_incident,Status,update_time,main_circuit,Desc1,NPI,Desc2,API,Desc3,Distance,'New',combined_drr ))
        conn.commit()

        return redirect('/')

        # Get all records
    

    return render_template('Create_HV.html', Scheme = Scheme, Region=Region)

@app.route('/CreateLV')
def Create_lv():

    cursor.execute("select * from PROSPER.Schemes")
    Scheme = cursor.fetchall()
    cursor.execute("select * from PROSPER.Regions")
    Region = cursor.fetchall()

    print(Scheme)
    if request.method == 'POST':
        
        
        # Create a new record
        Scheme = request.form['Scheme']
        Region = request.form['Region']
        District = request.form['District']
        DOI = request.form['doi']
        TOI = request.form['toi']
        combined_doi = convert_string_to_datetime(DOI, TOI)
        DRR = request.form['drr']
        DRRT = request.form['drrt']
        combined_drr = convert_string_to_datetime(DRR, DRRT)
        Closed_flag = request.form['name']
        RE = request.form['responsible_engineer']
        Eng_Desg = request.form['engineer_Designation']
        Error_status = request.form['Status']
        split_incident = request.form['SplitIncident']
        Status = request.form['name']
        update_time = request.form['name']
        main_circuit = request.form['Circuit']
        Desc1 = request.form['Desc1']
        NPI = request.form['NPI']
        Desc2 = request.form['Desc2']
        API = request.form['API']
        Desc3 = request.form['Desc3']
        Distance = request.form['Distance']
        cursor.execute('INSERT INTO PROSPER.Incidents_Stage1 (SCHEME_CODE,REGION_CODE,OPZONES,I_INC_DATE_TIME,I_REPORT_DATE_TIME, I_CLOSED_FLAG, KH_ENG_NAME,KH_ENG_DESIG,SPLIT_INCIDENT,hl_job_ref_no,I_STATUS,I_LAST_UPDATED,REPORTING SCHEME,I_MAIN_CIRCUIT,I_MC_DESC,H_NEAR_ISOL_POINT,H_NIP_DESC,H_AUTO_ISOL_POINT,H_AIP_DESC) VALUES (?)', 
                       (Scheme,Region,District,combined_doi,combined_drr,'C',RE,Eng_Desg,Error_status,split_incident,Status,update_time,main_circuit,Desc1,NPI,Desc2,API,Desc3,Distance,'New',combined_drr ))
        conn.commit()

        return redirect('/')

        # Get all records
    

    return render_template('Create_LV.html', Scheme = Scheme, Region=Region)



@app.route('/Createtrans')
def create_Transmission():

    cursor.execute("select * from PROSPER.Schemes")
    Scheme = cursor.fetchall()
    cursor.execute("select * from PROSPER.Regions")
    Region = cursor.fetchall()

    print(Scheme)
    if request.method == 'POST':
        
        
        # Create a new record
        Scheme = request.form['Scheme']
        Region = request.form['Region']
        District = request.form['District']
        DOI = request.form['doi']
        TOI = request.form['toi']
        combined_doi = convert_string_to_datetime(DOI, TOI)
        DRR = request.form['drr']
        DRRT = request.form['drrt']
        combined_drr = convert_string_to_datetime(DRR, DRRT)
        Closed_flag = request.form['name']
        RE = request.form['responsible_engineer']
        Eng_Desg = request.form['engineer_Designation']
        Error_status = request.form['Status']
        split_incident = request.form['SplitIncident']
        Status = request.form['name']
        update_time = request.form['name']
        main_circuit = request.form['Circuit']
        Desc1 = request.form['Desc1']
        NPI = request.form['NPI']
        Desc2 = request.form['Desc2']
        API = request.form['API']
        Desc3 = request.form['Desc3']
        Distance = request.form['Distance']
        cursor.execute('INSERT INTO PROSPER.Incidents_Stage1 (SCHEME_CODE,REGION_CODE,OPZONES,I_INC_DATE_TIME,I_REPORT_DATE_TIME, I_CLOSED_FLAG, KH_ENG_NAME,KH_ENG_DESIG,SPLIT_INCIDENT,hl_job_ref_no,I_STATUS,I_LAST_UPDATED,REPORTING SCHEME,I_MAIN_CIRCUIT,I_MC_DESC,H_NEAR_ISOL_POINT,H_NIP_DESC,H_AUTO_ISOL_POINT,H_AIP_DESC) VALUES (?)', 
                       (Scheme,Region,District,combined_doi,combined_drr,'C',RE,Eng_Desg,Error_status,split_incident,Status,update_time,main_circuit,Desc1,NPI,Desc2,API,Desc3,Distance,'New',combined_drr ))
        conn.commit()

        return redirect('/')

        # Get all records
    

    return render_template('Create_trans.html', Scheme = Scheme, Region=Region)


if __name__ == '__main__':
    app.run(debug=True)