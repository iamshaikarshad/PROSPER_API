# proper_crud
This repo will be used to develop python Flask application which serves as a CRUD application to the dedicated pool
